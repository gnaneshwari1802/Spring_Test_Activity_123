package com.accenture.lkm.test;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.accenture.lkm.Employee;

//Write valid annotations
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="/com/accenture/lkm/resources/my_springbean.xml")
public class TestEmployeeCollections {
	@Autowired
	private Employee employee;
	
	@Test
	public void testValidMapNotNull()
	{
		Assert.assertTrue(employee.getMapProperty()!=null);
	}
	
	@Test
	public void testValidMapSize()
	{
		Assert.assertFalse(employee.getMapProperty().isEmpty());
	}
	
	@Test
	public void testValidMapKey()
	{
		Assert.assertTrue(employee.getMapProperty().containsKey("Key1"));
	}
	
	@Test
	public void testValidMapValue()
	{
		Assert.assertTrue(employee.getMapProperty().containsValue("1"));
	}
	
	@Test
	public void testValidListNotNull()
	{
		Assert.assertTrue(employee.getListProperty()!=null);
	}
	
	@Test
	public void testValidListSize()
	{
		Assert.assertFalse(employee.getListProperty().isEmpty());
	}
	
	@Test
	public void testValidListContent()
	{
		Assert.assertTrue(employee.getListProperty().contains(333));
	}
	
	@Test
	public void testValidSetNotNull()
	{
		Assert.assertTrue(employee.getSetProperty()!=null);
	}
	
	@Test
	public void testValidSetSize() {
		Assert.assertFalse(employee.getSetProperty().isEmpty());
	}
	
	@Test
	public void testValidSetContent()
	{
		Assert.assertTrue(employee.getSetProperty().contains(212));
	}

}