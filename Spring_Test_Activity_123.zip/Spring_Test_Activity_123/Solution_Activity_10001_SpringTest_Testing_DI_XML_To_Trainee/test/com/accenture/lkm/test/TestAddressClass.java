package com.accenture.lkm.test;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.accenture.lkm.Address;
import com.accenture.lkm.Employee;
//Write valid annotations
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="/com/accenture/lkm/resources/my_springbean.xml")
public class TestAddressClass {
	@Autowired
	private Address address;
	@Test
	public void testAddress()
	{
		Assert.assertTrue(address!=null);
	}
	
	@Test
	public void testAddressLine1Valid()
	{
		Assert.assertTrue(address.getAddressLine1().equals("HSR Layout, Sector1"));
	}
	
	@Test
	public void testAddressLine2Valid()
	{
		Assert.assertTrue(address.getAddressLine2().equalsIgnoreCase("Bangalore, Karnataka"));
	}
	
	@Test
	public void testAddressLine1Invalid()
	{
		Assert.assertFalse(address.getAddressLine1().isEmpty());
	}
	
	@Test
	public void testAddressLine2Invalid()
	{
		Assert.assertFalse(address.getAddressLine2().isEmpty());
	}
	
}