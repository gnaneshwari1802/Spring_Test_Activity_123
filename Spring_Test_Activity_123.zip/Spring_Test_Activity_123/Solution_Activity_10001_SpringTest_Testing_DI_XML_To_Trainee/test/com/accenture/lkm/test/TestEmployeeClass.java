package com.accenture.lkm.test;

import org.springframework.beans.factory.annotation.Autowired;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import java.lang.NullPointerException;

import com.accenture.lkm.Employee;

//Write valid annotations
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="/com/accenture/lkm/resources/my_springbean.xml")
public class TestEmployeeClass {
	@Autowired
	private Employee employee;
	
	@Test
	public void testEmployee()
	{
		Assert.assertTrue(employee!=null);
	}
	
	@Test
	public void testEmployeeSalary()
	{
		Assert.assertTrue(employee.getSalary()==200000);
	}
	
	@Test
	public void testEmployeeName()
	{
		Assert.assertTrue(employee.getEmployeeName().equals("Jack"));
	}
	
	@Test
	public void testSalaryInValid()
	{
		Assert.assertTrue(employee.getSalary()!=null);
	}
	
	@Test
	public void testEmployeeNameInValid()
	{
		Assert.assertFalse(employee.getEmployeeName().isEmpty());
	}
	
}